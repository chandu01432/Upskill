"""
Customer Churn Analysis
========================
Dataset : Telco-style Customer Churn dataset (7043 customers, 21 columns)

This script performs:
1. Data filtering task    -> customers with a Two-year contract, Mailed check
                              payment method, and Churn = 'Yes'
2. Linear Regression       -> predict MonthlyCharges from tenure
3. Logistic Regression     -> (a) simple: Churn ~ MonthlyCharges
                               (b) multiple: Churn ~ tenure + MonthlyCharges
4. Data Visualization      -> pie charts, bar charts, and model diagnostic plots

Run:
    python3 churn_analysis.py
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (
    mean_squared_error,
    confusion_matrix,
    accuracy_score,
    ConfusionMatrixDisplay,
)

# ---------------------------------------------------------------
# Setup
# ---------------------------------------------------------------
sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110

DATA_PATH = "data/customer_churn.csv"
PLOTS_DIR = "plots"
OUTPUTS_DIR = "outputs"

df = pd.read_csv(DATA_PATH)

# TotalCharges has some blank strings (customers with tenure == 0);
# coerce to numeric and drop those rows for the modelling steps.
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df = df.dropna(subset=["TotalCharges"]).reset_index(drop=True)

print(f"Dataset loaded: {df.shape[0]} rows, {df.shape[1]} columns\n")

# =================================================================
# 1. FILTER: Two year contract + Mailed check + Churn == 'Yes'
# =================================================================
two_mail_yes = df[
    (df["Contract"] == "Two year")
    & (df["PaymentMethod"] == "Mailed check")
    & (df["Churn"] == "Yes")
]

print("=" * 60)
print("TASK 1: Two-year contract + Mailed check + Churn = Yes")
print("=" * 60)
print(f"Matching customers found: {len(two_mail_yes)}")
print(two_mail_yes.head(), "\n")

two_mail_yes.to_csv(f"{OUTPUTS_DIR}/two_mail_yes.csv", index=False)

# =================================================================
# 2. LINEAR REGRESSION: MonthlyCharges ~ tenure
# =================================================================
print("=" * 60)
print("TASK 2: Linear Regression (MonthlyCharges ~ tenure)")
print("=" * 60)

X_lin = df[["tenure"]]
y_lin = df["MonthlyCharges"]

# i. 70:30 train-test split
X_train_lin, X_test_lin, y_train_lin, y_test_lin = train_test_split(
    X_lin, y_lin, test_size=0.30, random_state=42
)

# ii. Build model on train, predict on test
lin_model = LinearRegression()
lin_model.fit(X_train_lin, y_train_lin)
y_pred_lin = lin_model.predict(X_test_lin)

# iii/v. Root Mean Square Error
mse = mean_squared_error(y_test_lin, y_pred_lin)
rmse = np.sqrt(mse)

# iv. Error in prediction (residuals), stored in `error`
error = y_test_lin.values - y_pred_lin

print(f"Intercept: {lin_model.intercept_:.4f}")
print(f"Coefficient (tenure): {lin_model.coef_[0]:.4f}")
print(f"RMSE on test set: {rmse:.4f}")
print(f"First 5 residuals (error): {np.round(error[:5], 4)}\n")

# =================================================================
# 3a. LOGISTIC REGRESSION (simple): Churn ~ MonthlyCharges
# =================================================================
print("=" * 60)
print("TASK 3a: Simple Logistic Regression (Churn ~ MonthlyCharges)")
print("=" * 60)

df["Churn_flag"] = df["Churn"].map({"Yes": 1, "No": 0})

X_simple = df[["MonthlyCharges"]]
y_simple = df["Churn_flag"]

# i. 65:35 split
X_train_s, X_test_s, y_train_s, y_test_s = train_test_split(
    X_simple, y_simple, test_size=0.35, random_state=42
)

# ii. Fit + predict
log_simple = LogisticRegression()
log_simple.fit(X_train_s, y_train_s)
y_pred_s = log_simple.predict(X_test_s)

# iii. Confusion matrix + accuracy
cm_simple = confusion_matrix(y_test_s, y_pred_s)
acc_simple = accuracy_score(y_test_s, y_pred_s)

print("Confusion Matrix:\n", cm_simple)
print(f"Accuracy: {acc_simple:.4f}\n")

# =================================================================
# 3b. LOGISTIC REGRESSION (multiple): Churn ~ tenure + MonthlyCharges
# =================================================================
print("=" * 60)
print("TASK 3b: Multiple Logistic Regression (Churn ~ tenure + MonthlyCharges)")
print("=" * 60)

X_multi = df[["tenure", "MonthlyCharges"]]
y_multi = df["Churn_flag"]

# i. 80:20 split
X_train_m, X_test_m, y_train_m, y_test_m = train_test_split(
    X_multi, y_multi, test_size=0.20, random_state=42
)

# ii. Fit + predict
log_multi = LogisticRegression()
log_multi.fit(X_train_m, y_train_m)
y_pred_m = log_multi.predict(X_test_m)

# iii. Confusion matrix + accuracy
cm_multi = confusion_matrix(y_test_m, y_pred_m)
acc_multi = accuracy_score(y_test_m, y_pred_m)

print("Confusion Matrix:\n", cm_multi)
print(f"Accuracy: {acc_multi:.4f}\n")

# =================================================================
# 4. DATA VISUALIZATION
# =================================================================
print("=" * 60)
print("Generating visualizations...")
print("=" * 60)

# ---- 4.1 Pie chart: overall churn distribution -----------------
plt.figure(figsize=(6, 6))
churn_counts = df["Churn"].value_counts()
colors = ["#4C9F70", "#E8615A"]
plt.pie(
    churn_counts,
    labels=churn_counts.index,
    autopct="%1.1f%%",
    startangle=90,
    colors=colors,
    explode=(0, 0.05),
    shadow=True,
    textprops={"fontsize": 12},
)
plt.title("Overall Customer Churn Distribution", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/01_pie_overall_churn.png")
plt.close()

# ---- 4.2 Pie chart: contract type distribution -----------------
plt.figure(figsize=(6, 6))
contract_counts = df["Contract"].value_counts()
plt.pie(
    contract_counts,
    labels=contract_counts.index,
    autopct="%1.1f%%",
    startangle=90,
    colors=sns.color_palette("pastel"),
    shadow=True,
    textprops={"fontsize": 12},
)
plt.title("Customer Distribution by Contract Type", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/02_pie_contract_type.png")
plt.close()

# ---- 4.3 Bar chart: churn rate by contract type -----------------
plt.figure(figsize=(7, 5))
churn_by_contract = (
    df.groupby("Contract")["Churn_flag"].mean().sort_values() * 100
)
ax = sns.barplot(
    x=churn_by_contract.index,
    y=churn_by_contract.values,
    hue=churn_by_contract.index,
    palette="viridis",
    legend=False,
)
for i, v in enumerate(churn_by_contract.values):
    ax.text(i, v + 1, f"{v:.1f}%", ha="center", fontweight="bold")
plt.title("Churn Rate by Contract Type", fontsize=14, fontweight="bold")
plt.ylabel("Churn Rate (%)")
plt.xlabel("Contract Type")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/03_bar_churn_by_contract.png")
plt.close()

# ---- 4.4 Bar chart: churn count by payment method ---------------
plt.figure(figsize=(8, 5))
pay_churn = pd.crosstab(df["PaymentMethod"], df["Churn"])
pay_churn.plot(kind="bar", stacked=True, color=colors, ax=plt.gca())
plt.title("Churn by Payment Method", fontsize=14, fontweight="bold")
plt.ylabel("Number of Customers")
plt.xlabel("Payment Method")
plt.xticks(rotation=20, ha="right")
plt.legend(title="Churn")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/04_bar_churn_by_payment.png")
plt.close()

# ---- 4.5 Scatter + regression line: tenure vs MonthlyCharges ----
plt.figure(figsize=(7, 5))
plt.scatter(X_test_lin, y_test_lin, alpha=0.3, label="Actual", color="#4C72B0")
order = np.argsort(X_test_lin["tenure"].values)
plt.plot(
    X_test_lin["tenure"].values[order],
    y_pred_lin[order],
    color="red",
    linewidth=2,
    label="Predicted (Linear Fit)",
)
plt.title("Linear Regression: Tenure vs Monthly Charges", fontsize=14, fontweight="bold")
plt.xlabel("Tenure (months)")
plt.ylabel("Monthly Charges")
plt.legend()
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/05_linear_regression_fit.png")
plt.close()

# ---- 4.6 Residual distribution ----------------------------------
plt.figure(figsize=(7, 5))
sns.histplot(error, kde=True, color="#8172B2")
plt.axvline(0, color="black", linestyle="--")
plt.title("Distribution of Prediction Errors (Residuals)", fontsize=14, fontweight="bold")
plt.xlabel("Residual (Actual - Predicted)")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/06_residual_distribution.png")
plt.close()

# ---- 4.7 Confusion matrix heatmaps -------------------------------
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
ConfusionMatrixDisplay(cm_simple, display_labels=["No Churn", "Churn"]).plot(
    ax=axes[0], cmap="Blues", colorbar=False
)
axes[0].set_title(f"Simple Logistic Regression\nAccuracy = {acc_simple:.2%}")

ConfusionMatrixDisplay(cm_multi, display_labels=["No Churn", "Churn"]).plot(
    ax=axes[1], cmap="Greens", colorbar=False
)
axes[1].set_title(f"Multiple Logistic Regression\nAccuracy = {acc_multi:.2%}")

plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/07_confusion_matrices.png")
plt.close()

# ---- 4.8 Model accuracy comparison bar chart ---------------------
plt.figure(figsize=(6, 5))
models = ["Simple Logistic\n(MonthlyCharges)", "Multiple Logistic\n(tenure + MonthlyCharges)"]
accs = [acc_simple, acc_multi]
bars = plt.bar(models, accs, color=["#55A868", "#4C72B0"])
for bar, acc in zip(bars, accs):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        acc + 0.01,
        f"{acc:.2%}",
        ha="center",
        fontweight="bold",
    )
plt.ylim(0, 1)
plt.title("Model Accuracy Comparison", fontsize=14, fontweight="bold")
plt.ylabel("Accuracy")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/08_accuracy_comparison.png")
plt.close()

print(f"All plots saved to '{PLOTS_DIR}/' directory.\n")

# =================================================================
# 5. SAVE SUMMARY REPORT
# =================================================================
summary = f"""
CUSTOMER CHURN ANALYSIS - SUMMARY REPORT
==========================================

1. FILTER TASK
   Customers with Two-year contract, Mailed check payment, Churn = Yes: {len(two_mail_yes)}
   (saved to outputs/two_mail_yes.csv)

2. LINEAR REGRESSION (MonthlyCharges ~ tenure)
   Train/Test split : 70/30
   Intercept        : {lin_model.intercept_:.4f}
   Coefficient      : {lin_model.coef_[0]:.4f}
   RMSE             : {rmse:.4f}

3a. SIMPLE LOGISTIC REGRESSION (Churn ~ MonthlyCharges)
   Train/Test split : 65/35
   Confusion Matrix :
   {cm_simple}
   Accuracy         : {acc_simple:.4f}

3b. MULTIPLE LOGISTIC REGRESSION (Churn ~ tenure + MonthlyCharges)
   Train/Test split : 80/20
   Confusion Matrix :
   {cm_multi}
   Accuracy         : {acc_multi:.4f}
"""

with open(f"{OUTPUTS_DIR}/summary_report.txt", "w") as f:
    f.write(summary)

print(summary)
print("Analysis complete. See 'outputs/' and 'plots/' folders for all results.")

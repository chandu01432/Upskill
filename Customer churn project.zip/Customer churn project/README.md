# Customer Churn Analysis

A machine learning project that analyzes customer churn using **Linear Regression**, **Logistic Regression**, and **exploratory data visualization** on a telecom customer dataset (7,043 customers, 21 features).

## 📊 Project Overview

This project explores customer churn behavior and builds predictive models to answer:
- Which specific customer segment is most/least likely to churn?
- Can we predict `MonthlyCharges` from a customer's `tenure`?
- Can we predict `Churn` from billing behavior alone, and does adding `tenure` improve the model?

## 📁 Project Structure

```
churn_project/
├── data/
│   └── customer_churn.csv        # Raw dataset
├── outputs/
│   ├── two_mail_yes.csv          # Filtered customer segment (Task 1)
│   └── summary_report.txt        # Text summary of all model results
├── plots/
│   ├── 01_pie_overall_churn.png
│   ├── 02_pie_contract_type.png
│   ├── 03_bar_churn_by_contract.png
│   ├── 04_bar_churn_by_payment.png
│   ├── 05_linear_regression_fit.png
│   ├── 06_residual_distribution.png
│   ├── 07_confusion_matrices.png
│   └── 08_accuracy_comparison.png
├── churn_analysis.py             # Main analysis script
└── README.md
```

## 🔍 1. Customer Segmentation

Filtered all customers with a **Two-year contract**, **Mailed check** as payment method, and **Churn = 'Yes'**, stored in `two_mail_yes`. This segment is tiny (3 customers out of 7,043) — long-term, low-friction-payment customers rarely churn, which is confirmed again in the churn-by-contract chart below.

## 📈 2. Linear Regression — `MonthlyCharges ~ tenure`

| Step | Detail |
|------|--------|
| Split | 70% train / 30% test |
| Intercept | ~55.06 |
| Coefficient (tenure) | ~0.29 |
| RMSE | ~28.97 |

Tenure alone explains only a small part of the variance in monthly charges (customers on the same plan for years can still be on very different billing tiers), which is why the RMSE is fairly high relative to the charge range — visible in the wide scatter around the fit line.

## 🔐 3. Logistic Regression

**a. Simple** — `Churn ~ MonthlyCharges` (65/35 split)
- Accuracy: ~74%
- The model leans entirely on the majority "No Churn" class — a reminder that accuracy alone can be misleading on an imbalanced target, and a single billing feature isn't enough to catch churners.

**b. Multiple** — `Churn ~ tenure + MonthlyCharges` (80/20 split)
- Accuracy: ~78%
- Adding `tenure` meaningfully improves the model's ability to actually catch churn cases (see the two confusion matrices side by side in `07_confusion_matrices.png`).

## 📊 4. Visualizations

- **Pie charts** — overall churn split, contract-type distribution
- **Bar charts** — churn rate by contract type, churn by payment method
- **Regression plot** — tenure vs. monthly charges with fitted line
- **Residual histogram** — spread of prediction errors
- **Confusion matrix heatmaps** — simple vs. multiple logistic model
- **Accuracy comparison bar chart**

## 🚀 Running the Project

```bash
pip install pandas numpy scikit-learn matplotlib seaborn
python3 churn_analysis.py
```

## 🛠️ Tech Stack

`Python` · `pandas` · `NumPy` · `scikit-learn` · `matplotlib` · `seaborn`

## 👤 Author

**Chandan Reddy D**
Aspiring Data Scientist | [GitHub](https://github.com/chandu01432) · [LinkedIn](https://linkedin.com/in/chandanreddy07)
